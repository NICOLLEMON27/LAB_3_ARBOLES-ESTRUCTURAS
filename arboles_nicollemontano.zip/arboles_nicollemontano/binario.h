/**
* @file
* @brief Arbol binario de busqueda
* @author Nicolle Monta�o
* @copyright MIT license
*/

#ifndef BINARIO_H
#define BINARIO_H
using std::cout;
using std::endl;

namespace arbol{
	template <class T>
	
	/**
	* @brief Arbol binario de busqueda
	*/	
	class binario{
	private:
		
		/**
		* @brief Nodo binario 
		*/
		struct nodo{
			T dato; /*!< Dato alamcenado*/
			nodo * izq; /*!< Referencia al hijo izquierdo*/
			nodo * der;/*!< Referencia al hijo derecho*/
			
			nodo(T dato):dato(dato),izq(nullptr),der(nullptr){
				
			}
			
			/**
			* @brief Verifica si el nodo es una hoja
			*/			
			bool es_hoja(){
				return(izq==nullptr&&der==nullptr);
				
			}
			/**
			* @brief Verifica si el nodo contiene el dato especificado
			* @param dato Dato a verificar
			*/
			bool contiene(T dato){
				return this->dato==dato;
			}
		};
		nodo * raiz=nullptr;
		
		/**
		* @brief Recorrido Preorden a partir de n (n-> dato,n->izq,n->der)
		* @param n Nodo de inicio del recorrido
		*/	
		void preorden(nodo * n){
			if (n ==nullptr){
				return;
			}
			cout<<" "<<n->dato;
			//invocar recursivamente el preorden de los hijos
			preorden(n->izq);
			preorden(n->der);
		}
		
		/**
		* @brief Recorrido inorden a partir de n (n->izq,n-> dato,n->der)
		* @param n Nodo de inicio del recorrido
		*/	
		void inorden(nodo * n){
			if (n ==nullptr){
				return;
			}
			inorden(n->izq);
			cout<<" "<<n->dato;
			//invocar recursivamente el inorden de los hijos
			inorden(n->der);
		}
			
		/**
		* @brief Recorrido posorden a partir de n (n->izq,n->der,n-> dato)
		* @param n Nodo de inicio del recorrido
		*/	
		void posorden(nodo * n){
			if (n ==nullptr){
				return;
			}
			posorden(n->izq);
			posorden(n->der);
			cout<<" "<<n->dato;
			//invocar recursivamente el posorden de los hijos
	
		}
				
		/**
		* @brief Intenta insertar un nuevo dato a partir de padre
		* @param padre Potencial padre del nodo
		* @param n Nuevo nodo
		* @return true si n nodo pudo ser insertado	
		*/	
		bool insertar(nodo * padre,nodo * n){
		//verificar si el dato ya esta en el arbol
		if(padre->dato==n->dato){
		
			return false;
		}	
			
		//tratar de insertar en los hijos
		
		if(padre->dato>n->dato){
			//insertar a la izquierda
			if(padre->izq==nullptr){
				//el nuevo nodo de convierte en el hijo izquierdo
				padre->izq=n;
				return true;
			}else{
				return insertar(padre->izq,n);
			}
		}else{
			//insertar a la derecha
			if(padre->der==nullptr){
				padre->der=n;
				return true;
			}else{
				return insertar(padre->der,n);
			}
		}
		}
		
		void eliminar(nodo*padre,nodo*n,T dato){
			
		}
		/**
		* @brief Encuentra el mayor de los menores (m�ximo en el sub�rbol izquierdo)
		* @return El mayor de los menores si existe, o un valor por defecto si el �rbol no tiene sub�rbol izquierdo
		*/
		T mayor_de_los_menores() {
			if (es_vacio()) {
				// �rbol vac�o, retorna un valor por defecto de tipo T
				return T();
			}
			
			if (raiz->izq == nullptr) {
				// No hay sub�rbol izquierdo, no existe mayor de los menores
				return T();
			}
			
			nodo* actual = raiz->izq;  // Empieza en el sub�rbol izquierdo
			
			// Encuentra el nodo m�s a la derecha del sub�rbol izquierdo
			while (actual->der != nullptr) {
				actual = actual->der;
			}
			
			// Devuelve el valor m�ximo en el sub�rbol izquierdo
			return actual->dato;
		}
		/**
		* @brief Encuentra el menor de los mayores (m�nimo en el sub�rbol derecho)
		* @return El menor de los mayores si existe, o un valor por defecto si el �rbol no tiene sub�rbol derecho
		*/
		T menor_de_los_mayores() {
			if (es_vacio()) {
				// �rbol vac�o, retorna un valor por defecto de tipo T
				return T();
			}
			
			if (raiz->der == nullptr) {
				// No hay sub�rbol derecho, no existe menor de los mayores
				return T();
			}
			
			nodo* actual = raiz->der;  // Empieza en el sub�rbol derecho
			
			// Encuentra el nodo m�s a la izquierda del sub�rbol derecho
			while (actual->izq != nullptr) {
				actual = actual->izq;
			}
			
			// Devuelve el valor m�nimo en el sub�rbol derecho
			return actual->dato;
		}
	public:
		
		/**
		* @brief Permie verificar si el arbol esta vacio
		* @return true si el arbol esta vacio
		*/
		bool es_vacio(){
			return(raiz== nullptr);
		}
			
		/**
		* @brief Inserta un nuevo dato en el arbol
		* @param dato Nuevo dato a insertar
		*/		
		void insertar(T dato){
			cout<< "Insertar  "<<dato<<endl;
			nodo * n =new nodo(dato);
			if(es_vacio()){
				raiz=n;
			}else{ 
			
			//Liberar la memoria del nodo si no se pudo insertar
			if (!insertar(raiz,n)){
				delete n;
			}
		}
		}
			
		/**
		* @brief Elimina un dato
		* @param dato  Dato a eliminar
		*/		
		void eliminar(T dato){
		//1.Si el arbol es vacio terminar
		
		if(es_vacio()){
			return;
		}	
		//POST. El arbol esta vacio
		//2. Si la raiz es hoja, y contiene el dato a eliminar
		if(raiz->es_hoja()&&raiz->contiene(dato)){
			//raiz=nulo y liberar memoria del dato
			nodo* tmp=raiz;
			raiz=nullptr;
			delete tmp;
			
			return;
		}
		//POST. El arbol no esta vacio y/o la raiz No contiene el dato a eliminar
		//3. Recursivamente, eliminar el dato 
		eliminar(nullptr,raiz,dato);
		
		
		}	
		
		/**
		* @brief Imprime e recorrido en preOrden (dato,izq,der)
		*/
		void preorden(){
			preorden(raiz);
			
		}
			/**
			* @brief Imprime e recorrido en preOrden (dato,izq,der)
			*/
			void inorden(){
				inorden(raiz);
				
			}
		/**
		* @brief Imprime e recorrido en inOrden (dato,izq,der)
		*/
		void posorden(){
			posorden(raiz);
			
		}
			
	};

};
#endif
